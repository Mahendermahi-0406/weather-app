package com.example.session18weatherapp

object Constants {
    const val BASE_URL = "https://api.openweathermap.org/data/2.5/";
    const val API_KEY = "3eec6a374356475b6bdc095afa20e"
}